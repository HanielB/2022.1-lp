#include <iostream>

class A
{
 public:
  virtual void vf() { std::cout << "I'm A!\n"; }
  void f() { std::cout << "A!\n"; }
};

class B
{
 public:
  virtual void vf() { std::cout << "I'm B!\n"; }
  void f() { std::cout << "B!\n"; }
};

class C : public A, public B
{
 public:
  void vf() override { std::cout << "I'm C!\n"; }
  void f() { std::cout << "C!\n"; }
};

void aux(A* p)
{
  p->f();
  p->vf();
}

int main()
{
  C* pc = new C;
  // pc->A::f();
  // pc->B::f();
  pc->f();

  aux(pc);
}
